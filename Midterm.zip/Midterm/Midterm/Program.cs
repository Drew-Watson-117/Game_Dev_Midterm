﻿
using var game = new Midterm.Game1();
game.Run();
